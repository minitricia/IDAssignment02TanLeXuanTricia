/* Tabs (Home and Settings) */
function openPage(evt, pageName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(pageName).style.display = "block";
  evt.currentTarget.className += " active";

}

function openCalories(evt, caloriesName) {
  var i, subtabcontent, subtablinks;
  subtabcontent = document.getElementsByClassName("subtabcontent");
  for (i = 0; i < subtabcontent.length; i++) {
    subtabcontent[i].style.display = "none";
  }
  subtablinks = document.getElementsByClassName("subtablinks");
  for (i = 0; i < subtablinks.length; i++) {
    subtablinks[i].className = subtablinks[i].className.replace(" active", "");
  }
  document.getElementById(caloriesName).style.display = "block";
  evt.currentTarget.className += " active";

}


window.onload = function () {   //dataPoints. 

  /* Home Tab */
  startTab();
  startSubTab();

  CanvasJS.addColorSet("blueShades",
    [//colorSet Array

    "#ABC7FF",
    "#78a5ff",
    "rgb(227, 236, 255)"              
    ]);

  var chart = new CanvasJS.Chart("caloriesContainer", {
	animationEnabled: true,
	title:{
		text: "Calories (Gain/Burn)"
	},	
	axisY: {
		title: "kcal",
		color: "black",
	},
	toolTip: {
		shared: true
	},
	legend: {
		cursor:"pointer",
		itemclick: toggleDataSeries
	},

  /* Expenses Data */
	data: [{
		type: "column",
    color: "#78a5ff",
		name: "Gain",
		legendText: "Gain",
		showInLegend: true, 
		dataPoints:[
			{ label: "1 Jan", y: 1837 },
			{ label: "2 Jan", y: 2534 },
			{ label: "3 Jan", y: 3455 },
			{ label: "4 Jan", y: 3433 },
			{ label: "5 Jan", y: 1231 },
			{ label: "6 Jan", y: 2233 }
		]
	},

  /* Savings Data */
	{
		type: "column",	
    color: "#b5ceff",
		name: "Burn",
		legendText: "Burn",
		showInLegend: true,
		dataPoints:[
			{ label: "1 Jan", y: 1454 },
			{ label: "2 Jan", y: 824 },
			{ label: "3 Jan", y: 2131 },
			{ label: "4 Jan", y: 1231 },
			{ label: "5 Jan", y: 2313 },
			{ label: "6 Jan", y: 921 }
		]
	}]
});
chart.render();

var chart = new CanvasJS.Chart("caloriesneededContainer", {
	animationEnabled: true,
	exportEnabled: true,
  colorSet:  "blueShades",
	title: {
		text: "Calories Needed Per Day"
	},
	axisX: {
	},
	axisY: {
    interval: 250,
	}, 
	data: [{
		type: "rangeBar",
		showInLegend: true,
		indexLabel: "{y[#index]}",
		legendText: "Calories (kcal)",
		dataPoints: [
			{ x: 10, y:[1600, 2400], label: "Adult Women" },
			{ x: 20, y:[2000, 3000], label: "Adult Men" },
		]
	}]
});
chart.render();

var chart = new CanvasJS.Chart("obesityContainer", {
	animationEnabled: true,
  colorSet:  "blueShades",
	title: {
		text: "Obesity (USA)"
	},
	data: [{
		type: "pie",
		startAngle: 240,
		yValueFormatString: "##0.00\"%\"",
		indexLabel: "{label} {y}",
		dataPoints: [
			{y: 18.5, label: "Adults (93.3m)"},
			{y: 39.8, label: "Children and Teens (18.5m)"},
			{y: 41.7, label: "Others"},
		]
	}]
});
chart.render();
}


function toggleDataSeries(e) {
	if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
		e.dataSeries.visible = false;
	}
	else {
		e.dataSeries.visible = true;
	}
	chart.render();
}

/* Default Open Home Tab */
function startTab() {
  document.getElementById("defaultOpen").click();
}

function startSubTab() {
  document.getElementById("defaultOpenSub").click();
}

function darkMode1Function() {
  var element = document.body;
  element.classList.toggle("dark-mode1");
}

function darkMode2Function() {
  var element = document.body;
  element.classList.toggle("dark-mode2");
}

function darkMode3Function() {
  var element = document.body;
  element.classList.toggle("dark-mode3");
}