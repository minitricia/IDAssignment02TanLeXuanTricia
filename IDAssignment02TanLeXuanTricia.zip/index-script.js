/* Tabs (Signup and Login) */
function openLogin(evt, loginName) {
  var i, tabcontent, tablinks;
  tabcontent = document.getElementsByClassName("tabcontent");
  for (i = 0; i < tabcontent.length; i++) {
    tabcontent[i].style.display = "none";
  }
  tablinks = document.getElementsByClassName("tablinks");
  for (i = 0; i < tablinks.length; i++) {
    tablinks[i].className = tablinks[i].className.replace(" active", "");
  }
  document.getElementById(loginName).style.display = "block";
  evt.currentTarget.className += " active";

}

/* Display Chart */
window.onload = function () {

  /* Signup Tab */
  startTab();

	var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	title:{
		text: "Calories (Gain/Burn)"
	},	
	axisY: {
		title: "kcal",
		color: "black",
	},
	toolTip: {
		shared: true
	},
	legend: {
		cursor:"pointer",
		itemclick: toggleDataSeries
	},

  /* Expenses Data */
	data: [{
		type: "column",
    color: "#78a5ff",
		name: "Gain",
		legendText: "Gain",
		showInLegend: true, 
		dataPoints:[
			{ label: "1 Jan", y: 1837 },
			{ label: "2 Jan", y: 2242 },
			{ label: "3 Jan", y: 2345 },
			{ label: "4 Jan", y: 3454 },
			{ label: "5 Jan", y: 1454 },
			{ label: "6 Jan", y: 1789 }
		]
	},

  /* Savings Data */
	{
		type: "column",	
    color: "#b5ceff",
		name: "Burn",
		legendText: "Burn",
		showInLegend: true,
		dataPoints:[
			{ label: "1 Jan", y: 1454 },
			{ label: "2 Jan", y: 543 },
			{ label: "3 Jan", y: 405 },
			{ label: "4 Jan", y: 945 },
			{ label: "5 Jan", y: 1345 },
			{ label: "6 Jan", y: 1345 }
		]
	}]
});
chart.render();
}

function toggleDataSeries(e) {
	if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
		e.dataSeries.visible = false;
	}
	else {
		e.dataSeries.visible = true;
	}
	chart.render();
}

/* Default Open Signup Tab */
function startTab() {
  document.getElementById("defaultOpen").click();
}

function store() {
  alert('Your account has been created')
}
function check() {
  alert('Log In.');
}
